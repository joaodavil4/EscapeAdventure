package JogoDemo;

public class App {
	public static void main(String[] args) {
        (new Engine()).joga();
	}

}
