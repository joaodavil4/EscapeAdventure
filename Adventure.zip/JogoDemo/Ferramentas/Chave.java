package JogoDemo.Ferramentas;

import ClassesBasicas.Ferramenta;

public class Chave extends Ferramenta {
	public Chave() {
		super("Chave");
	}
}
