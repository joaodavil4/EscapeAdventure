package JogoDemo.Ferramentas;

import ClassesBasicas.Ferramenta;

public class Lanterna extends Ferramenta {

	public Lanterna() {
		super("Lanterna");
	}
}
