package JogoDemo.Ferramentas;

import ClassesBasicas.Ferramenta;

public class Picareta extends Ferramenta {

	public Picareta() {
		super("Picareta");
	}

}
