package JogoDemo;

public class FimDeJogoException extends RuntimeException {
	public FimDeJogoException() {
	}
}
